document.addEventListener("DOMContentLoaded", function () {
    const taskContainer = document.querySelector(".task-management");
    const listTitleElement = document.getElementById("list-title");
    const menuButton = document.getElementById("add-settings"); // Burger menu button
    const sidebar = document.getElementById("add-sidebar"); // Sidebar
    const timeDateElement = document.getElementById("time-date");
    const themeToggle = document.getElementById("theme-toggle");
    const body = document.body;
    const API_KEY = "54ae93dc22d2be6788d5f729b6f0ce85";
    const TOKEN = 'ATTA853fc8af3234b12fc797c12f7d510cf282c782e377dd1bcd86844e1eb638535fF8ADD6CA';
    const LIST_ID = '680f65e8d7ca14d630007032';
    const leftArrow = document.createElement('button');
    const rightArrow = document.createElement('button');
    

    if (menuButton && sidebar) {
        // Toggle sidebar when clicking the burger menu
        menuButton.addEventListener("click", function (event) {
            event.stopPropagation(); // Prevent the click from propagating to the document
            sidebar.classList.toggle("active");
        });

        // Close sidebar when clicking outside of it
        document.addEventListener("click", function (event) {
            if (!sidebar.contains(event.target) && !menuButton.contains(event.target)) {
                sidebar.classList.remove("active");
            }
        });
    } else {
        console.error("Burger menu button or sidebar not found!");
    }
    
    
    
    
    function fetchGMAIL() {
    fetch('https://script.google.com/macros/s/AKfycbwZYc2-6VSCmnaiA4BgKcAQa2tkaVbEp5zZ6GUMN4NIgsFO1vx-Cv4zqPs2xFEOevJARw/exec')
        .then(response => response.json())
        .then(data => {
        const notificationsSection = document.querySelector(".notifications ul");
            notificationsSection.innerHTML = ""; // Clear existing content

            data.forEach(email => {
            const li = document.createElement("li");
            li.innerHTML = `
                <strong>${email.subject}</strong><br>
                <em>${email.from}</em><br>
                <p>${email.body}</p>
            `;
            notificationsSection.appendChild(li);
            });
        })
        .catch(error => console.error("Error loading emails:", error));
    }
    
    // 1. Load the API client and OAuth 2.0 library
function loadClient() {
    gapi.load('client:auth2', initClient);
}

// 2. Initialize the client with your API key and OAuth credentials
function initClient() {
    gapi.client.init({
        apiKey: 'AIzaSyBLku1jYRz5kPGMpyF6_17clPgA-NTVllk', // Replace with your API Key
        clientId: '246444821254-591mf8enve7v8taeopvef0cjdslivhja.apps.googleusercontent.com', // Replace with your Client ID
        discoveryDocs: ['https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest'],
        scope: 'https://www.googleapis.com/auth/calendar.readonly',
    }).then(function () {
        // Listen for sign-in state changes
        gapi.auth2.getAuthInstance().isSignedIn.listen(updateSigninStatus);
        // Handle initial sign-in state
        updateSigninStatus(gapi.auth2.getAuthInstance().isSignedIn.get());
    });
}

// 3. Handle sign-in state changes
function updateSigninStatus(isSignedIn) {
    if (isSignedIn) {
        fetchEvents(); // If signed in, fetch calendar events
    } else {
        gapi.auth2.getAuthInstance().signIn(); // Sign in the user
    }
}

// 4. Fetch calendar events
function fetchEvents() {
    gapi.client.calendar.events.list({
        calendarId: 'primary', // 'primary' refers to the main user calendar
        timeMin: (new Date()).toISOString(), // Get events from now onwards
        maxResults: 10, // Limit the number of events
        singleEvents: true,
        orderBy: 'startTime',
    }).then(function(response) {
        const events = response.result.items;
        const eventContainer = document.querySelector('.project-overview');
        eventContainer.innerHTML = "<h2>Upcoming Events</h2>";
        
        if (events.length > 0) {
            events.forEach(event => {
                const eventElement = document.createElement('div');
                eventElement.classList.add('calendar-event');
                eventElement.innerHTML = `
                    <h3>${event.summary}</h3>
                    <p>${event.start.dateTime || event.start.date} - ${event.location || 'No location'}</p>
                    <p>${event.description || 'No description'}</p>
                `;
                eventContainer.appendChild(eventElement);
            });
        } else {
            eventContainer.innerHTML += "<p>No upcoming events</p>";
        }
    });
}

// 5. Sign-out function
function signOut() {
    gapi.auth2.getAuthInstance().signOut();
}

// 6. Load the client after the page loads
window.onload = loadClient;

        
    
        // Function to update time and date in GMT
        function updateTime() {
            const currentDate = new Date();
            const options = {
                weekday: 'long', // e.g., "Monday"
                year: 'numeric',
                month: 'long',  // e.g., "March"
                day: 'numeric',
                hour: '2-digit', // e.g., "12"
                minute: '2-digit', // e.g., "30"
                second: '2-digit', // e.g., "45"
                timeZoneName: 'short', // e.g., "GMT"
                timeZone: 'GMT' // Set to GMT time zone
            };
            
            // Format the date and time
            const formattedDateTime = currentDate.toLocaleString('en-GB', options);
    
            // Update the time/date element
            timeDateElement.textContent = formattedDateTime;
        }
    
        // Update the time/date every second
        setInterval(updateTime, 1000);
        
        
    
        
            // Check if the dark theme is already set in local storage
            if (localStorage.getItem('theme') === 'light') {
                body.classList.add('light-theme');
                themeToggle.checked = true;
            } else {
                body.classList.add('dark-theme');
            }
        
            // Listen for theme toggle
            themeToggle.addEventListener('change', function () {
                if (this.checked) {
                    body.classList.remove('dark-theme');
                    body.classList.add('light-theme');
                    localStorage.setItem('theme', 'light'); // Save the theme preference
                } else {
                    body.classList.remove('light-theme');
                    body.classList.add('dark-theme');
                    localStorage.setItem('theme', 'dark'); // Save the theme preference
                }
            });

            // Fetching Trello tasks
    
            let lists = []; // To store all lists
            let currentListIndex = 0; // Which list is currently being shown


            // Fetch all lists from the board
            function fetchLists() {
                fetch(`https://api.trello.com/1/boards/R6SUqEc8/lists?key=54ae93dc22d2be6788d5f729b6f0ce85&token=ATTA853fc8af3234b12fc797c12f7d510cf282c782e377dd1bcd86844e1eb638535fF8ADD6CA`)
                    .then(response => response.json())
                    .then(data => {
                        
                        lists = data;
                        if (lists.length > 0) {
                            fetchTrelloTasks(lists[currentListIndex].id); // Show first list initially
                            createArrows(); // Create left/right navigation arrows
                        } else {
                            taskContainer.innerHTML = "<p>No lists found!</p>";
                        }  
                    })
                    .catch(error => {
                        console.error('Error fetching lists:', error);
                        taskContainer.innerHTML = "<p>Failed to load lists.</p>";
                    });
            }
            
           function fetchTrelloTasks(listId) {
        fetch(`https://api.trello.com/1/lists/${listId}/cards?key=${API_KEY}&token=${TOKEN}`)
        .then(response => response.json())
        .then(cards => {
            taskContainer.innerHTML = ''; // Clear existing tasks
            
            const headerRow = document.createElement('div');
            headerRow.style.display = 'flex';
            headerRow.style.justifyContent = 'space-between';
            headerRow.style.alignItems = 'center';
            headerRow.style.marginBottom = '10px';

            const title = document.createElement('h2');
            title.textContent = lists[currentListIndex].name;
            title.style.flex = '1';
            title.style.textAlign = 'center';
            title.style.margin = '0';

            
            
            leftArrow.textContent = '⬅️';
            rightArrow.textContent = '➡️';
            leftArrow.classList.add('arrow-button');
            rightArrow.classList.add('arrow-button');
            
            headerRow.appendChild(leftArrow);
            headerRow.appendChild(title);
            headerRow.appendChild(rightArrow);
            taskContainer.appendChild(headerRow);

            // Add each card
            cards.forEach(card => {
                const cardElement = document.createElement('div');
                cardElement.classList.add('task-card');
                cardElement.innerHTML = `<p>${card.name}</p>`;
                taskContainer.appendChild(cardElement);
            });
        })
        .catch(error => {
            console.error('Error fetching Trello tasks:', error);
            taskContainer.innerHTML = '<p>Failed to load tasks.</p>';
        });
}

            
                    
            // Create left/right arrow buttons
            function createArrows() {
                
                

                taskContainer.prepend(leftArrow);
                taskContainer.prepend(rightArrow);

                leftArrow.addEventListener('click', () => {
                    currentListIndex = (currentListIndex - 1 + lists.length) % lists.length; // Move left
                    fetchTrelloTasks(lists[currentListIndex].id);
                });

                rightArrow.addEventListener('click', () => {
                    currentListIndex = (currentListIndex + 1) % lists.length; // Move right
                    fetchTrelloTasks(lists[currentListIndex].id);
                });
            }
    
            
            
            fetchLists();
            
            
            
        setInterval(() => {
    fetchTrelloTasks(lists[currentListIndex].id);
}, 5 * 60 * 1000);


});
